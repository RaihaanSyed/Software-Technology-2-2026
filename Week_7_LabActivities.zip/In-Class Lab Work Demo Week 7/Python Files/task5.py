import tkinter as tk
from tkinter import messagebox, ttk
import time
import random
import string
import matplotlib.pyplot as plt

# ===== Red-Black Tree Node and Class =====

RED = "RED"
BLACK = "BLACK"

class RBNode:
    def __init__(self, name, phone, color=RED):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    def __init__(self):
        # Sentinel NIL node
        self.NIL = RBNode(None, None, BLACK)
        self.NIL.left = self.NIL
        self.NIL.right = self.NIL
        self.NIL.parent = self.NIL
        self.root = self.NIL

    def _left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent == self.NIL:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def _right_rotate(self, y):
        x = y.left
        y.left = x.right
        if x.right != self.NIL:
            x.right.parent = y
        x.parent = y.parent
        if y.parent == self.NIL:
            self.root = x
        elif y == y.parent.left:
            y.parent.left = x
        else:
            y.parent.right = x
        x.right = y
        y.parent = x

    def insert(self, name, phone):
        # Update phone if name already exists
        existing = self.search(self.root, name)
        if existing != self.NIL:
            existing.phone = phone
            return

        z = RBNode(name, phone)
        z.left = self.NIL
        z.right = self.NIL
        z.parent = self.NIL

        y = self.NIL
        x = self.root
        while x != self.NIL:
            y = x
            if z.name < x.name:
                x = x.left
            else:
                x = x.right

        z.parent = y
        if y == self.NIL:
            self.root = z
        elif z.name < y.name:
            y.left = z
        else:
            y.right = z

        self._insert_fixup(z)

    def _insert_fixup(self, z):
        while z.parent.color == RED:
            if z.parent == z.parent.parent.left:
                y = z.parent.parent.right  # uncle
                if y.color == RED:
                    # Case 1: recolor
                    z.parent.color = BLACK
                    y.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.right:
                        # Case 2: left rotate
                        z = z.parent
                        self._left_rotate(z)
                    # Case 3: right rotate
                    z.parent.color = BLACK
                    z.parent.parent.color = RED
                    self._right_rotate(z.parent.parent)
            else:
                y = z.parent.parent.left  # uncle (mirror)
                if y.color == RED:
                    z.parent.color = BLACK
                    y.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.left:
                        z = z.parent
                        self._right_rotate(z)
                    z.parent.color = BLACK
                    z.parent.parent.color = RED
                    self._left_rotate(z.parent.parent)
        self.root.color = BLACK

    def _transplant(self, u, v):
        if u.parent == self.NIL:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def _minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, name):
        z = self.search(self.root, name)
        if z == self.NIL:
            return

        y = z
        y_original_color = y.color
        if z.left == self.NIL:
            x = z.right
            self._transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self._transplant(z, z.left)
        else:
            y = self._minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self._transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self._transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        if y_original_color == BLACK:
            self._delete_fixup(x)

    def _delete_fixup(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                w = x.parent.right
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self._left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == BLACK and w.right.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.right.color == BLACK:
                        w.left.color = BLACK
                        w.color = RED
                        self._right_rotate(w)
                        w = x.parent.right
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.right.color = BLACK
                    self._left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self._right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == BLACK and w.left.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.left.color == BLACK:
                        w.right.color = BLACK
                        w.color = RED
                        self._left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.left.color = BLACK
                    self._right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

    def search(self, node, name):
        if node == self.NIL or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, node=None, res=None):
        if node is None:
            node = self.root
        if res is None:
            res = []
        if node != self.NIL:
            self.inorder(node.left, res)
            res.append((node.name, node.phone))
            self.inorder(node.right, res)
        return res


# ===== RBT GUI Application (same style as Task 3 AVLApp) =====

class RBTApp:
    def __init__(self, master):
        self.tree = RedBlackTree()
        self.master = master
        master.title("RBT Contact Directory Visualizer")

        # Input Frame
        self.frame = tk.Frame(master)
        self.frame.pack(pady=10)

        tk.Label(self.frame, text="Name:").grid(row=0, column=0, padx=5)
        self.name_entry = tk.Entry(self.frame)
        self.name_entry.grid(row=0, column=1, padx=5)

        tk.Label(self.frame, text="Phone:").grid(row=1, column=0, padx=5)
        self.phone_entry = tk.Entry(self.frame)
        self.phone_entry.grid(row=1, column=1, padx=5)

        # Button Frame
        self.btn_frame = tk.Frame(master)
        self.btn_frame.pack(pady=5)

        tk.Button(self.btn_frame, text="Insert", command=self.insert_contact, width=10).grid(row=0, column=0, padx=5)
        tk.Button(self.btn_frame, text="Search", command=self.search_contact, width=10).grid(row=0, column=1, padx=5)
        tk.Button(self.btn_frame, text="Delete", command=self.delete_contact, width=10).grid(row=0, column=2, padx=5)
        tk.Button(self.btn_frame, text="Show All", command=self.show_all, width=10).grid(row=0, column=3, padx=5)

        # Text Output
        self.output_text = tk.Text(master, height=8, width=65)
        self.output_text.pack(pady=10)

        # Visualization Canvas
        self.canvas = tk.Canvas(master, width=800, height=400, bg="white", borderwidth=2, relief="groove")
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please provide both name and phone.")
            return
        self.tree.insert(name, phone)
        messagebox.showinfo("Success", f"Contact '{name}' added/updated.")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Enter a name to search.")
            return
        node = self.tree.search(self.tree.root, name)
        self.output_text.delete(1.0, tk.END)
        if node != self.tree.NIL:
            self.output_text.insert(tk.END, f"RESULT:\nName: {node.name}\nPhone: {node.phone}\nColor: {node.color}")
        else:
            self.output_text.insert(tk.END, "Contact not found.")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Enter a name to delete.")
            return
        self.tree.delete(name)
        messagebox.showinfo("Delete", f"Process complete for '{name}'.")
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder()
        if not contacts:
            self.output_text.insert(tk.END, "Directory is empty.")
        else:
            self.output_text.insert(tk.END, "ALPHABETICAL LIST:\n")
            for n, p in contacts:
                self.output_text.insert(tk.END, f"- {n}: {p}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root != self.tree.NIL:
            self.master.update_idletasks()
            self._draw_node(self.tree.root, 400, 40, 180)

    def _draw_node(self, node, x, y, x_offset):
        if node == self.tree.NIL:
            return
        radius = 20

        # Draw edges first (so they sit behind circles)
        if node.left != self.tree.NIL:
            self.canvas.create_line(x, y, x - x_offset, y + 70, fill="gray")
            self._draw_node(node.left, x - x_offset, y + 70, x_offset // 1.8)

        if node.right != self.tree.NIL:
            self.canvas.create_line(x, y, x + x_offset, y + 70, fill="gray")
            self._draw_node(node.right, x + x_offset, y + 70, x_offset // 1.8)

        # Red nodes are red, black nodes are dark gray
        fill_color = "tomato" if node.color == RED else "gray25"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                fill=fill_color, outline="black")
        # Label shows name (sliced if too long) and R/B color indicator
        label = f"{node.name[:5]}\n({node.color[0]})"
        self.canvas.create_text(x, y, text=label, font=("Arial", 8, "bold"), fill="white")


# ===== BST (from Task 4) =====

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        while root.left:
            root = root.left
        return root

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root


# ===== AVL Tree (from Task 4) =====

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def right_rotate(self, z):
        y = z.left; T3 = y.right
        y.right = z; z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right; T2 = y.left
        y.left = z; z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone; return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        b = self.get_balance(node)
        if b > 1 and name < node.left.name:   return self.right_rotate(node)
        if b < -1 and name > node.right.name: return self.left_rotate(node)
        if b > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left); return self.right_rotate(node)
        if b < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right); return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        while node.left: node = node.left
        return node

    def delete(self, root, name):
        if not root: return root
        if name < root.name:   root.left  = self.delete(root.left,  name)
        elif name > root.name: root.right = self.delete(root.right, name)
        else:
            if not root.left:  return root.right
            if not root.right: return root.left
            t = self.min_value_node(root.right)
            root.name = t.name; root.phone = t.phone
            root.right = self.delete(root.right, t.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        b = self.get_balance(root)
        if b > 1 and self.get_balance(root.left) >= 0:   return self.right_rotate(root)
        if b > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left); return self.right_rotate(root)
        if b < -1 and self.get_balance(root.right) <= 0: return self.left_rotate(root)
        if b < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right); return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name: return node
        if name < node.name: return self.search(node.left, name)
        return self.search(node.right, name)


# ===== Benchmarking (extends Task 4 to include RBT) =====

def benchmark(n=1000, search_fraction=0.5, delete_count=100, verbose=True):
    names  = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    search_names = random.sample(names, int(n * search_fraction)) + ['notfoundname'] * int(n * (1 - search_fraction))
    delete_names = random.sample(names, delete_count)

    # --- BST ---
    bst = BST()
    start = time.time()
    for i in range(n): bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start

    start = time.time()
    for name in search_names: bst.search(bst.root, name)
    bst_search_time = time.time() - start

    start = time.time()
    for name in delete_names: bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start

    # --- AVL ---
    avl = AVLTree()
    start = time.time()
    for i in range(n): avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start

    start = time.time()
    for name in search_names: avl.search(avl.root, name)
    avl_search_time = time.time() - start

    start = time.time()
    for name in delete_names: avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start

    # --- RBT ---
    rbt = RedBlackTree()
    start = time.time()
    for i in range(n): rbt.insert(names[i], phones[i])
    rbt_insert_time = time.time() - start

    start = time.time()
    for name in search_names: rbt.search(rbt.root, name)
    rbt_search_time = time.time() - start

    start = time.time()
    for name in delete_names: rbt.delete(name)
    rbt_delete_time = time.time() - start

    results = {
        'Insertions': (bst_insert_time, avl_insert_time, rbt_insert_time),
        'Searches':   (bst_search_time, avl_search_time, rbt_search_time),
        'Deletions':  (bst_delete_time, avl_delete_time, rbt_delete_time),
    }

    if verbose:
        print(f"Benchmarking with {n} entries:\n")
        print("Operation    BST Time (sec)  AVL Time (sec)  RBT Time (sec)")
        print("--------------------------------------------------------------")
        for op, (b, a, r) in results.items():
            print(f"{op:<12} {b:.6f}       {a:.6f}       {r:.6f}")

    return results


# ===== Benchmark GUI (extends Task 4 BenchmarkApp to include RBT) =====

class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs RBT Benchmark")

        self.label = tk.Label(master, text="Run benchmark with 1000 entries?")
        self.label.pack(pady=5)

        self.run_btn = tk.Button(master, text="Run Benchmark", command=self.run_benchmark)
        self.run_btn.pack(pady=5)

        self.result_text = tk.Text(master, height=6, width=65)
        self.result_text.pack(pady=10)

        # Treeview with BST, AVL, RBT columns
        self.tree = ttk.Treeview(master, columns=("Operation", "BST", "AVL", "RBT"), show='headings')
        self.tree.heading("Operation", text="Operation")
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.heading("RBT", text="RBT Time (s)")
        self.tree.column("Operation", width=100)
        self.tree.column("BST", width=110)
        self.tree.column("AVL", width=110)
        self.tree.column("RBT", width=110)
        self.tree.pack(pady=10)

        self.plot_btn = tk.Button(master, text="Show Scaling Graph", command=self.show_scaling_graph)
        self.plot_btn.pack(pady=5)

    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)
        results = benchmark(verbose=False)

        summary = (
            f"Insertion: BST {results['Insertions'][0]:.6f}s  AVL {results['Insertions'][1]:.6f}s  RBT {results['Insertions'][2]:.6f}s\n"
            f"Search:    BST {results['Searches'][0]:.6f}s  AVL {results['Searches'][1]:.6f}s  RBT {results['Searches'][2]:.6f}s\n"
            f"Deletion:  BST {results['Deletions'][0]:.6f}s  AVL {results['Deletions'][1]:.6f}s  RBT {results['Deletions'][2]:.6f}s\n"
        )
        self.result_text.insert(tk.END, summary)

        for row in self.tree.get_children():
            self.tree.delete(row)
        for op, (b, a, r) in results.items():
            self.tree.insert('', tk.END, values=(op, f"{b:.6f}", f"{a:.6f}", f"{r:.6f}"))

    def show_scaling_graph(self):
        sizes = [1000, 2000, 5000, 7500, 10000]
        bst_times = {'insert': [], 'search': [], 'delete': []}
        avl_times = {'insert': [], 'search': [], 'delete': []}
        rbt_times = {'insert': [], 'search': [], 'delete': []}

        for n in sizes:
            names  = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
            phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
            search_names = random.sample(names, min(100, n))
            delete_names = random.sample(names, min(50,  n))

            # BST
            bst = BST()
            t = time.time()
            for i in range(n): bst.root = bst.insert(bst.root, names[i], phones[i])
            bst_times['insert'].append(time.time() - t)
            t = time.time()
            for nm in search_names: bst.search(bst.root, nm)
            bst_times['search'].append(time.time() - t)
            t = time.time()
            for nm in delete_names: bst.root = bst.delete(bst.root, nm)
            bst_times['delete'].append(time.time() - t)

            # AVL
            avl = AVLTree()
            t = time.time()
            for i in range(n): avl.root = avl.insert(avl.root, names[i], phones[i])
            avl_times['insert'].append(time.time() - t)
            t = time.time()
            for nm in search_names: avl.search(avl.root, nm)
            avl_times['search'].append(time.time() - t)
            t = time.time()
            for nm in delete_names: avl.root = avl.delete(avl.root, nm)
            avl_times['delete'].append(time.time() - t)

            # RBT
            rbt = RedBlackTree()
            t = time.time()
            for i in range(n): rbt.insert(names[i], phones[i])
            rbt_times['insert'].append(time.time() - t)
            t = time.time()
            for nm in search_names: rbt.search(rbt.root, nm)
            rbt_times['search'].append(time.time() - t)
            t = time.time()
            for nm in delete_names: rbt.delete(nm)
            rbt_times['delete'].append(time.time() - t)

        plt.figure(figsize=(12, 8))

        plt.subplot(3, 1, 1)
        plt.plot(sizes, bst_times['insert'], label='BST Insert')
        plt.plot(sizes, avl_times['insert'], label='AVL Insert')
        plt.plot(sizes, rbt_times['insert'], label='RBT Insert')
        plt.ylabel('Time (seconds)')
        plt.title('Insertion Time vs Input Size')
        plt.legend()

        plt.subplot(3, 1, 2)
        plt.plot(sizes, bst_times['search'], label='BST Search')
        plt.plot(sizes, avl_times['search'], label='AVL Search')
        plt.plot(sizes, rbt_times['search'], label='RBT Search')
        plt.ylabel('Time (seconds)')
        plt.title('Search Time vs Input Size')
        plt.legend()

        plt.subplot(3, 1, 3)
        plt.plot(sizes, bst_times['delete'], label='BST Delete')
        plt.plot(sizes, avl_times['delete'], label='AVL Delete')
        plt.plot(sizes, rbt_times['delete'], label='RBT Delete')
        plt.xlabel('Number of Nodes')
        plt.ylabel('Time (seconds)')
        plt.title('Deletion Time vs Input Size')
        plt.legend()

        plt.tight_layout()
        plt.show()


# ===== Run the app =====

if __name__ == "__main__":
    sizes_to_test = [1000, 2000, 5000, 7500, 10000]

    root1 = tk.Tk()
    app1 = RBTApp(root1)

    root2 = tk.Toplevel(root1)
    app2 = BenchmarkApp(root2)

    root1.mainloop()