# graph_visualizer.py
from graph import Graph
import tkinter as tk
from tkinter import simpledialog, messagebox
import math
import time
import threading

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry('700x700')
        self.graph = graph

        self.canvas = tk.Canvas(self, width=650, height=550, bg='white')
        self.canvas.pack(pady=10)

        self.vertex_positions = {}
        self.node_radius = 20
        self.spacing = 180
        self.center = (325, 275)
        self.vertex_circles = {}
        self.edge_lines = {}

        control_frame = tk.Frame(self)
        control_frame.pack()

        tk.Button(control_frame, text="Add Vertex", command=self.add_vertex).pack(side=tk.LEFT, padx=3)
        tk.Button(control_frame, text="Remove Vertex", command=self.remove_vertex).pack(side=tk.LEFT, padx=3)
        tk.Button(control_frame, text="Add Edge", command=self.add_edge).pack(side=tk.LEFT, padx=3)
        tk.Button(control_frame, text="Remove Edge", command=self.remove_edge).pack(side=tk.LEFT, padx=3)
        tk.Button(control_frame, text="Run BFS", command=lambda: self.run_traversal("bfs")).pack(side=tk.LEFT, padx=3)
        tk.Button(control_frame, text="Run DFS", command=lambda: self.run_traversal("dfs")).pack(side=tk.LEFT, padx=3)
        tk.Button(control_frame, text="Reset", command=self.reset_colors).pack(side=tk.LEFT, padx=3)

        self.info_label = tk.Label(self, text="")
        self.info_label.pack()

        self.draw_graph()

    # -----------------------
    # Smooth circle helper
    # -----------------------
    def create_smooth_circle(self, x, y, r, **kwargs):
        points = []
        steps = 60
        for i in range(steps):
            angle = 2 * math.pi * i / steps
            points.append(x + r * math.cos(angle))
            points.append(y + r * math.sin(angle))
        return self.canvas.create_polygon(points, smooth=True, **kwargs)

    # -----------------------
    # Draw graph
    # -----------------------
    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()
        self.edge_lines.clear()

        vertices = list(self.graph.graph.keys())
        n = len(vertices)
        if n == 0:
            return

        angle_gap = 360 / n
        cx, cy = self.center

        for i, v in enumerate(vertices):
            angle = math.radians(i * angle_gap)
            x = cx + self.spacing * math.cos(angle)
            y = cy + self.spacing * math.sin(angle)
            self.vertex_positions[v] = (x, y)

        for v in vertices:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                if self.graph.directed:
                    dx, dy = x2 - x1, y2 - y1
                    dist = math.hypot(dx, dy)
                    if dist == 0: continue
                    ux, uy = dx / dist, dy / dist
                    sx, sy = x1 + ux * self.node_radius, y1 + uy * self.node_radius
                    ex, ey = x2 - ux * self.node_radius, y2 - uy * self.node_radius
                else:
                    sx, sy, ex, ey = x1, y1, x2, y2

                line = self.canvas.create_line(
                    sx, sy, ex, ey,
                    arrow=tk.LAST if self.graph.directed else None,
                    arrowshape=(12,16,5),
                    width=2, smooth=True
                )
                self.edge_lines[(v,nbr)] = line

                if self.graph.weighted:
                    mid_x, mid_y = (sx+ex)/2, (sy+ey)/2
                    weight = self.graph.weights.get((v,nbr), "")
                    self.canvas.create_text(mid_x, mid_y, text=str(weight), fill="red", font=("Helvetica", 10, "italic"))

        # Draw nodes on top
        for v in vertices:
            x, y = self.vertex_positions[v]
            circle = self.create_smooth_circle(x, y, self.node_radius, fill='lightblue', outline='black', width=1.5)
            self.vertex_circles[v] = circle
            self.canvas.create_text(x, y, text=v, font=("Helvetica", 11, "bold"))

    # -----------------------
    # Reset
    # -----------------------
    def reset_colors(self):
        for circle in self.vertex_circles.values():
            self.canvas.itemconfig(circle, fill='lightblue')
        for line in self.edge_lines.values():
            self.canvas.itemconfig(line, fill='black', width=2)
        self.info_label.config(text="")

    # -----------------------
    # Highlight helpers
    # -----------------------
    def highlight_vertex(self, v, color):
        if v in self.vertex_circles:
            self.canvas.itemconfig(self.vertex_circles[v], fill=color)
            self.update()

    def highlight_edge(self, v1, v2, color):
        if (v1,v2) in self.edge_lines:
            self.canvas.itemconfig(self.edge_lines[(v1,v2)], fill=color, width=3)
            self.update()

    # -----------------------
    # Add / Remove vertices and edges
    # -----------------------
    def add_vertex(self):
        v = simpledialog.askstring("Add Vertex", "Enter vertex name:")
        if v and v not in self.graph.graph:
            self.graph.add_vertex(v)
            self.draw_graph()

    def remove_vertex(self):
        v = simpledialog.askstring("Remove Vertex", "Enter vertex name:")
        if v in self.graph.graph:
            self.graph.remove_vertex(v)
            self.draw_graph()

    def add_edge(self):
        v1 = simpledialog.askstring("Add Edge", "Start vertex:")
        v2 = simpledialog.askstring("Add Edge", "End vertex:")
        weight = 0
        if self.graph.weighted:
            try:
                weight = int(simpledialog.askstring("Add Edge", "Edge weight:"))
            except:
                weight = 0
        if v1 in self.graph.graph and v2 in self.graph.graph:
            self.graph.add_edge(v1,v2,weight)
            self.draw_graph()
        else:
            messagebox.showerror("Error","Vertices must exist!")

    def remove_edge(self):
        v1 = simpledialog.askstring("Remove Edge","Start vertex:")
        v2 = simpledialog.askstring("Remove Edge","End vertex:")
        if v1 in self.graph.graph and v2 in self.graph.graph.get(v1,[]):
            self.graph.remove_edge(v1,v2)
            self.draw_graph()
        else:
            messagebox.showerror("Error","Edge does not exist!")

    # -----------------------
    # Traversals
    # -----------------------
    def run_traversal(self, method):
        def worker():
            self.reset_colors()
            if not self.graph.graph:
                return
            visited = set()
            start = next(iter(self.graph.graph))

            if method=="bfs":
                queue=[start]
                while queue:
                    v = queue.pop(0)
                    if v not in visited:
                        visited.add(v)
                        self.highlight_vertex(v,"orange")
                        time.sleep(0.4)
                        for nbr in self.graph.graph[v]:
                            if nbr not in visited:
                                queue.append(nbr)
                                self.highlight_edge(v,nbr,"green")
            elif method=="dfs":
                stack=[start]
                while stack:
                    v = stack.pop()
                    if v not in visited:
                        visited.add(v)
                        self.highlight_vertex(v,"purple")
                        time.sleep(0.4)
                        for nbr in self.graph.graph[v]:
                            if nbr not in visited:
                                stack.append(nbr)
                                self.highlight_edge(v,nbr,"blue")

        threading.Thread(target=worker).start()


# -----------------------
# Test
# -----------------------
if __name__=="__main__":
    g = Graph(directed=True, weighted=True)
    for v in ["A","B","C","D"]:
        g.add_vertex(v)
    g.add_edge("A","B",10)
    g.add_edge("B","C",20)
    g.add_edge("C","A",30)
    g.add_edge("C","D",5)

    app = GraphVisualizer(g)
    app.mainloop()