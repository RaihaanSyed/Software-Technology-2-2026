class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}          # adjacency list
        self.weights = {}        # store weights if needed
        self.directed = directed
        self.weighted = weighted

    # Add a vertex
    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    # Add an edge
    def add_edge(self, v1, v2, weight=0):
        if v1 in self.graph and v2 in self.graph:
            self.graph[v1].append(v2)

            if self.weighted:
                self.weights[(v1, v2)] = weight

            # If undirected, add reverse edge
            if not self.directed:
                self.graph[v2].append(v1)
                if self.weighted:
                    self.weights[(v2, v1)] = weight
        else:
            print("One or both vertices not found.")

    # Remove an edge
    def remove_edge(self, v1, v2):
        if v1 in self.graph and v2 in self.graph[v1]:
            self.graph[v1].remove(v2)

        if not self.directed:
            if v2 in self.graph and v1 in self.graph[v2]:
                self.graph[v2].remove(v1)

        if (v1, v2) in self.weights:
            del self.weights[(v1, v2)]

    # Remove a vertex
    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]

        # Remove all edges pointing to this vertex
        for v in self.graph:
            if vertex in self.graph[v]:
                self.graph[v].remove(vertex)

        # Remove any weights related to this vertex
        to_delete = []
        for edge in self.weights:
            if vertex in edge:
                to_delete.append(edge)

        for edge in to_delete:
            del self.weights[edge]

    # Print the graph
    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                edges = [
                    f"{nbr}(w={self.weights.get((vertex, nbr), 0)})"
                    for nbr in self.graph[vertex]
                ]
                print(f"{vertex} -> {edges}")
            else:
                print(f"{vertex} -> {self.graph[vertex]}")

    # Breadth First Search (BFS)
    def bfs(self, start):
        visited = []          # stores visited order
        queue = []            # queue for BFS

        if start not in self.graph:
            print("Start vertex not found.")
            return visited

        queue.append(start)

        while queue:
            vertex = queue.pop(0)

            if vertex not in visited:
                visited.append(vertex)

                # Add all neighbours to queue
                for neighbour in self.graph[vertex]:
                    if neighbour not in visited:
                        queue.append(neighbour)

        return visited
    
        # Depth First Search (DFS)
    def dfs(self, start):
        visited = []      # stores visited order
        stack = []        # stack for DFS

        if start not in self.graph:
            print("Start vertex not found.")
            return visited

        stack.append(start)

        while stack:
            vertex = stack.pop()

            if vertex not in visited:
                visited.append(vertex)

                # Add neighbours in reverse to maintain correct order
                for neighbour in reversed(self.graph[vertex]):
                    if neighbour not in visited:
                        stack.append(neighbour)

        return visited
    
        # Detect cycle in an undirected graph using DFS
    def has_undirected_cycle(self):
        visited = set()

        def dfs(vertex, parent):
            visited.add(vertex)

            for neighbour in self.graph[vertex]:
                # If neighbour not visited, continue DFS
                if neighbour not in visited:
                    if dfs(neighbour, vertex):
                        return True
                # If visited and not parent → cycle found
                elif neighbour != parent:
                    return True

            return False

        # Check all components
        for v in self.graph:
            if v not in visited:
                if dfs(v, None):
                    return True

        return False
    
    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                edges = [
                    f"{nbr}(w={self.weights.get((vertex, nbr), 0)})"
                    for nbr in self.graph[vertex]
                ]
                print(f"{vertex} -> {edges}")
            else:
                print(f"{vertex} -> {self.graph[vertex]}")