from graph import Graph
import tkinter as tk
import math
import time
import threading

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry('700x700')
        self.graph = graph

        # --- Canvas ---
        self.canvas = tk.Canvas(self, width=650, height=600, bg='white')
        self.canvas.pack(pady=10)

        # --- Graph drawing helpers ---
        self.vertex_positions = {}
        self.node_radius = 20
        self.spacing = 180
        self.center = (325, 300)
        self.vertex_circles = {}
        self.edge_lines = {}

        # --- Controls ---
        control_frame = tk.Frame(self)
        control_frame.pack(pady=5)

        tk.Button(control_frame, text="Run BFS",
                  command=lambda: self.run_traversal("bfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Run DFS",
                  command=lambda: self.run_traversal("dfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Undirected Cycle",
                  command=self.run_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Directed Cycle",
                  command=self.run_directed_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Reset",
                  command=self.reset_colors).pack(side=tk.LEFT, padx=5)

        # Dropdown to switch graph type
        self.graph_type_var = tk.StringVar(value="Directed")
        tk.Label(control_frame, text="Graph Type:").pack(side=tk.LEFT, padx=5)
        tk.OptionMenu(control_frame, self.graph_type_var, "Directed", "Undirected", command=self.switch_graph).pack(side=tk.LEFT)

        # Info label
        self.info_label = tk.Label(self, text="", font=("Helvetica", 12))
        self.info_label.pack(pady=5)

        self.draw_graph()

    # -----------------------
    # Smooth circle helper
    # -----------------------
    def create_smooth_circle(self, x, y, r, **kwargs):
        points = []
        steps = 60
        for i in range(steps):
            angle = 2 * math.pi * i / steps
            points.append(x + r * math.cos(angle))
            points.append(y + r * math.sin(angle))
        return self.canvas.create_polygon(points, smooth=True, **kwargs)

    # -----------------------
    # Draw graph
    # -----------------------
    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()
        self.edge_lines.clear()

        vertices = list(self.graph.graph.keys())
        n = len(vertices)
        if n == 0:
            return

        angle_gap = 360 / n
        cx, cy = self.center

        # Place vertices in circle
        for i, v in enumerate(vertices):
            angle = math.radians(i * angle_gap)
            x = cx + self.spacing * math.cos(angle)
            y = cy + self.spacing * math.sin(angle)
            self.vertex_positions[v] = (x, y)

        # Draw edges first
        for v in vertices:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                if self.graph.directed:
                    dx = x2 - x1
                    dy = y2 - y1
                    dist = math.hypot(dx, dy)
                    if dist == 0:
                        continue
                    ux, uy = dx / dist, dy / dist
                    sx = x1 + ux * self.node_radius
                    sy = y1 + uy * self.node_radius
                    ex = x2 - ux * self.node_radius
                    ey = y2 - uy * self.node_radius
                else:
                    sx, sy = x1, y1
                    ex, ey = x2, y2

                line = self.canvas.create_line(
                    sx, sy, ex, ey,
                    arrow=tk.LAST if self.graph.directed else None,
                    arrowshape=(12, 16, 5),
                    width=2,
                    smooth=True
                )
                self.edge_lines[(v, nbr)] = line

        # Draw vertices on top
        for v in vertices:
            x, y = self.vertex_positions[v]
            circle = self.create_smooth_circle(
                x, y, self.node_radius,
                fill='lightblue', outline='black', width=1.5
            )
            self.vertex_circles[v] = circle
            self.canvas.create_text(x, y, text=v, font=("Helvetica", 11, "bold"))

    # -----------------------
    # Reset colors
    # -----------------------
    def reset_colors(self):
        for circle in self.vertex_circles.values():
            self.canvas.itemconfig(circle, fill='lightblue')
        for line in self.edge_lines.values():
            self.canvas.itemconfig(line, fill='black', width=2)
        self.info_label.config(text="")

    # -----------------------
    # Highlight helpers
    # -----------------------
    def highlight_vertex(self, v, color):
        if v in self.vertex_circles:
            self.canvas.itemconfig(self.vertex_circles[v], fill=color)
            self.update()

    def highlight_edge(self, v1, v2, color):
        if (v1, v2) in self.edge_lines:
            self.canvas.itemconfig(self.edge_lines[(v1, v2)], fill=color, width=3)
            self.update()

    # -----------------------
    # BFS / DFS
    # -----------------------
    def run_traversal(self, method):
        def worker():
            self.reset_colors()
            visited = set()
            start = next(iter(self.graph.graph))

            if method == "bfs":
                queue = [start]
                while queue:
                    v = queue.pop(0)
                    if v not in visited:
                        visited.add(v)
                        self.highlight_vertex(v, "orange")
                        time.sleep(0.5)
                        for nbr in self.graph.graph[v]:
                            if nbr not in visited:
                                queue.append(nbr)
                                self.highlight_edge(v, nbr, "green")

            elif method == "dfs":
                stack = [start]
                while stack:
                    v = stack.pop()
                    if v not in visited:
                        visited.add(v)
                        self.highlight_vertex(v, "purple")
                        time.sleep(0.5)
                        for nbr in self.graph.graph[v]:
                            if nbr not in visited:
                                stack.append(nbr)
                                self.highlight_edge(v, nbr, "blue")

        threading.Thread(target=worker).start()

    # -----------------------
    # Undirected cycle detection
    # -----------------------
    def run_cycle_detection(self):
        def worker():
            self.reset_colors()
            if self.graph.directed:
                self.info_label.config(text="Use undirected graph for this test.")
                return

            visited = set()

            def dfs(v, parent):
                visited.add(v)
                self.highlight_vertex(v, "yellow")
                time.sleep(0.5)
                for nbr in self.graph.graph[v]:
                    if nbr not in visited:
                        self.highlight_edge(v, nbr, "orange")
                        if dfs(nbr, v):
                            return True
                    elif nbr != parent:
                        self.highlight_edge(v, nbr, "red")
                        self.highlight_vertex(v, "red")
                        self.highlight_vertex(nbr, "red")
                        return True
                return False

            for v in self.graph.graph:
                if v not in visited:
                    if dfs(v, None):
                        self.info_label.config(text="Cycle detected!")
                        return
            self.info_label.config(text="No cycle found.")

        threading.Thread(target=worker).start()

    # -----------------------
    # Directed cycle detection
    # -----------------------
    def run_directed_cycle_detection(self):
        def worker():
            self.reset_colors()
            if not self.graph.directed:
                self.info_label.config(text="Use directed graph for this test.")
                return

            visited = set()
            rec_stack = set()

            def dfs(v):
                visited.add(v)
                rec_stack.add(v)
                self.highlight_vertex(v, "yellow")
                time.sleep(0.5)

                for nbr in self.graph.graph[v]:
                    if nbr not in visited:
                        if dfs(nbr):
                            return True
                    elif nbr in rec_stack:
                        self.highlight_edge(v, nbr, "red")
                        self.highlight_vertex(v, "red")
                        self.highlight_vertex(nbr, "red")
                        return True

                rec_stack.remove(v)
                return False

            for v in self.graph.graph:
                if v not in visited:
                    if dfs(v):
                        self.info_label.config(text="Directed cycle detected!")
                        return

            self.info_label.config(text="No directed cycle found.")

        threading.Thread(target=worker).start()

    # -----------------------
    # Switch graph type dynamically
    # -----------------------
    def switch_graph(self, choice):
        self.reset_colors()
        if choice == "Directed":
            self.graph.directed = True
            self.graph.graph.clear()
            for v in ['A', 'B', 'C', 'D']:
                self.graph.add_vertex(v)
            self.graph.add_edge('A', 'B')
            self.graph.add_edge('B', 'C')
            self.graph.add_edge('C', 'A')
            self.graph.add_edge('C', 'D')
        else:
            self.graph.directed = False
            self.graph.graph.clear()
            for v in ['A', 'B', 'C', 'D']:
                self.graph.add_vertex(v)
            self.graph.add_edge('A', 'B')
            self.graph.add_edge('B', 'C')
            self.graph.add_edge('C', 'A')
            self.graph.add_edge('C', 'D')

        self.draw_graph()
        self.info_label.config(text=f"Switched to {choice} graph.")

# -----------------------
# Run the visualizer
# -----------------------
if __name__ == "__main__":
    g = Graph(directed=True)
    for v in ['A', 'B', 'C', 'D']:
        g.add_vertex(v)
    g.add_edge('A', 'B')
    g.add_edge('B', 'C')
    g.add_edge('C', 'A')
    g.add_edge('C', 'D')

    app = GraphVisualizer(g)
    app.mainloop()