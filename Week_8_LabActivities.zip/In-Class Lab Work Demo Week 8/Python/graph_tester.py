from graph import Graph

# ── Basic undirected graph tests ──────────────────────────────────────────────
print("=" * 45)
print("UNDIRECTED GRAPH")
print("=" * 45)
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
g.add_edge('A', 'D')

g.print_graph()
print()

# ── Directed graph tests ──────────────────────────────────────────────────────
print("=" * 45)
print("DIRECTED GRAPH")
print("=" * 45)
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
g.add_edge('D', 'A')  # cycle back

g.print_graph()
print()

# ── Weighted directed graph tests ─────────────────────────────────────────────
print("=" * 45)
print("WEIGHTED DIRECTED GRAPH")
print("=" * 45)
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)
g.add_edge('C', 'D', 7)
g.add_edge('A', 'D', 50)

g.print_graph()
print()

# ── Removal tests ─────────────────────────────────────────────────────────────
print("=" * 45)
print("REMOVAL TESTS (Undirected)")
print("=" * 45)
removal_test = Graph()
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_vertex('D')

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
removal_test.add_edge('C', 'D')
removal_test.add_edge('A', 'D')

print("Initial graph:")
removal_test.print_graph()

print("\nAfter removing edge A--B:")
removal_test.remove_edge('A', 'B')
removal_test.print_graph()

print("\nAfter removing vertex C (and its edges):")
removal_test.remove_vertex('C')
removal_test.print_graph()

print("\nAttempting to remove a non-existent edge (A--C):")
removal_test.remove_edge('A', 'C')

print("\nAttempting to remove a non-existent vertex (Z):")
removal_test.remove_vertex('Z')

# -------------------------------
# BFS Test
# -------------------------------
print("\nBFS TEST")

g = Graph()

# Create graph: A → B → C with extra edges
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'D')

g.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

# -------------------------------
# DFS Test
# -------------------------------
print("\nDFS TEST")

# Use the SAME graph as BFS for comparison
g = Graph()

for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'D')

g.print_graph()

print("\nDFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

# -------------------------------
# Cycle Detection Test (Undirected)
# -------------------------------
print("\nCYCLE DETECTION TEST")

# ---- Graph WITH cycle (triangle) ----
cycle_graph = Graph(directed=False)

for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)

cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # creates a cycle

cycle_graph.print_graph()
print("Does cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())


# ---- Graph WITHOUT cycle (linear chain) ----
acyclic_graph = Graph(directed=False)

for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)

acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

acyclic_graph.print_graph()
print("Does acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())

# -------------------------------
# Weighted + Directed Graph Test
# -------------------------------
print("\nWEIGHTED DIRECTED GRAPH TEST")

wg = Graph(directed=True, weighted=True)

# Add vertices
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

# Add weighted edges
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

# Print graph
wg.print_graph()

# Print weights dictionary (optional but useful)
print("Weights stored:", wg.weights)