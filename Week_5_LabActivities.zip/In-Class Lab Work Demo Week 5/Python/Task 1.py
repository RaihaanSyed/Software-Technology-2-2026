import random
import timeit

print("\n--- Iterative and Recursion Mergesort ---\n")

# ---------------------
#       Iterative
# ---------------------
# BASIC ITERATIVE EXAMPLE
def sum_of_natural_numbers_iter(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

# Test
iter_result = sum_of_natural_numbers_iter(5)
print(f"The sum of the first 5 natural numbers is {iter_result} (Iterative).")

# ITERATIVELY CALCULATING FIBONACCI SEQUENCE
def fibonacci_iter(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

# Test
iter_result = fibonacci_iter(7)
print(f"The 7th Fibonacci number is {iter_result} (Iterative).")  # Output: 13


# CHALLENGE: Use iterative to calculate the factorial.
def factorial_iter(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Test
num = 5
result = factorial_iter(num)
print(f"The factorial of {num} is {result} (Iterative).")

# ---------------------
#       Recursion
# ---------------------
# RECURSION
# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case
    
# Example usage:
result = sum_of_natural_numbers(5)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers is {result} (Recursion).")


# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Example usage:
result = fibonacci(7)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The 7th Fibonacci number is {result} (Recursion).")


# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Example usage:
num = 5
result = factorial(num)
print(f"The factorial of {num} is {result} (Recursion).")


# ---------------------
#       Testing
# ---------------------

print("\n--- SUM COMPARISON ---")
n = 100
iter_time = timeit.timeit(lambda: sum_of_natural_numbers_iter(n), number=1000)
rec_time = timeit.timeit(lambda: sum_of_natural_numbers(n), number=1000)
print(f"Iterative time: {iter_time:.6f} seconds")
print(f"Recursion time: {rec_time:.6f} seconds")


print("\n--- FIBONACCI COMPARISON ---")
n = 20
iter_time = timeit.timeit(lambda: fibonacci_iter(n), number=1000)
rec_time = timeit.timeit(lambda: fibonacci(n), number=10)  # slow → fewer runs
print(f"Iterative time: {iter_time:.6f} seconds")
print(f"Recursion time: {rec_time:.6f} seconds")


print("\n--- FACTORIAL COMPARISON ---")
n = 20
iter_time = timeit.timeit(lambda: factorial_iter(n), number=1000)
rec_time = timeit.timeit(lambda: factorial(n), number=1000)
print(f"Iterative time: {iter_time:.6f} seconds")
print(f"Recursion time: {rec_time:.6f} seconds")

