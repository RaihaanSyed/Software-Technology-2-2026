from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Koch Snowflake") # Set a title

        self.width = 500
        self.height = 500

        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()

        Label(frame1, text="Enter order: ").pack(side=LEFT)

        self.order = StringVar()
        Entry(frame1, textvariable=self.order, width=5).pack(side=LEFT)

        Button(frame1, text="Draw", command=self.draw_snowflake).pack(side=LEFT)

        window.mainloop()

    def draw_snowflake(self):
        self.canvas.delete("all")

        try:
            order = int(self.order.get())
        except:
            order = 0

        # Triangle points
        p1 = (100, 350)
        p2 = (400, 350)
        p3 = (250, 100)

        # Draw 3 sides
        self.koch(order, p1, p2)
        self.koch(order, p2, p3)
        self.koch(order, p3, p1)

    def koch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1])
        else:
            x1, y1 = p1
            x5, y5 = p2

            # Divide line into 3 parts
            x2 = x1 + (x5 - x1) / 3
            y2 = y1 + (y5 - y1) / 3

            x3 = (x1 + x5) / 2 + math.sqrt(3) * (y1 - y5) / 6
            y3 = (y1 + y5) / 2 + math.sqrt(3) * (x5 - x1) / 6

            x4 = x1 + 2 * (x5 - x1) / 3
            y4 = y1 + 2 * (y5 - y1) / 3

            # Recursive calls
            self.koch(order - 1, (x1, y1), (x2, y2))
            self.koch(order - 1, (x2, y2), (x3, y3))
            self.koch(order - 1, (x3, y3), (x4, y4))
            self.koch(order - 1, (x4, y4), (x5, y5))


KochSnowflake()