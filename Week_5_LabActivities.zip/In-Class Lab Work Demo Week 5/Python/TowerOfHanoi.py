move_count = 0  # Global variable

def main():
    global move_count
    n = int(input("Enter number of disks: "))

    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')

    print(f"\nTotal number of moves: {move_count}")

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower 
def moveDisks(n, fromTower, toTower, auxTower):
    global move_count

    if n == 1:  # Base case
        #print("Move disk 1 from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)

        #print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1

        moveDisks(n - 1, auxTower, toTower, fromTower)


main() # Call the main function