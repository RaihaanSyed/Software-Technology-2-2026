import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 20
CANVAS_WIDTH = 600
CANVAS_HEIGHT = 200

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        # push
        tk.Label(control_frame, text="Pushed Value:").grid(row=0, column=0)
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)

        tk.Button(control_frame, text="Push", command=self.push_value)\
            .grid(row=0, column=2, padx=5)

        # pop
        tk.Button(control_frame, text="Pop", command=self.pop_value)\
            .grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    # -----------------------------
    # Drawing Functions
    # -----------------------------
    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill="lightgreen", outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2,
            text=str(data), font=("Arial", 16)
        )

    def draw_queue(self):
        self.canvas.delete("all")

        x = 20
        y = CANVAS_HEIGHT // 2 - NODE_HEIGHT // 2

        for i, val in enumerate(self.queue):
            self.draw_node(x, y, val)

            # Draw arrow →
            if i < len(self.queue) - 1:
                self.canvas.create_line(
                    x + NODE_WIDTH, y + NODE_HEIGHT / 2,
                    x + NODE_WIDTH + HORIZONTAL_GAP, y + NODE_HEIGHT / 2,
                    arrow=tk.LAST, width=2
                )

            x += NODE_WIDTH + HORIZONTAL_GAP

        # Labels
        if self.queue:
            # Front (left)
            self.canvas.create_text(
                20 + NODE_WIDTH / 2,
                y - 20,
                text="Front",
                fill="red",
                font=("Arial", 12)
            )

            # Rear (right)
            rear_x = 20 + (len(self.queue)-1) * (NODE_WIDTH + HORIZONTAL_GAP) + NODE_WIDTH / 2
            self.canvas.create_text(
                rear_x,
                y + NODE_HEIGHT + 20,
                text="Rear",
                fill="blue",
                font=("Arial", 12)
            )

    # -----------------------------
    # Queue Operations
    # -----------------------------
    def push_value(self):
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter an integer.")
            return

        self.queue.append(val)  # add to rear
        self.push_entry.delete(0, tk.END)

        self.status_label.config(text=f"Pushed {val}")
        self.draw_queue()

    def pop_value(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty.")
            return

        val = self.queue.pop(0)  # remove from front

        self.status_label.config(text=f"Popped {val}")
        self.draw_queue()


# -----------------------------
# Run Program
# -----------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    # Example test
    # app.queue = [10, 20, 30]
    # app.draw_queue()

    root.mainloop()